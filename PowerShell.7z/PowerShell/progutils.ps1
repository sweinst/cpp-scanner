function fsrc
{
    param(
    [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
    [string]${Pattern},
    [string[]]${Path} = @($PWD.Path),
    [int]${Context} = 0,
    [switch]${CaseSensitive} = $false,
    [switch]${json} = $false,
    [switch]${ListMatchesOnly} = $false,
    [switch]${MultiLine} = $false,
    [switch]${WordsOnly} = $false,
    [switch]${Count} = $false
    )
    $arguments=@()

    if (-not ${CaseSensitive}) { $arguments += '--ignore-case'}
    if (${json}) { $arguments += '--json'}
    if (${WordsOnly}) { $arguments += '--word-regexp'}
    if (${MultiLine}) { $arguments += '--multiline'}
    if (${Count}) { $arguments += '--count'}
    if (${ListMatchesOnly}) { $arguments += '--files-with-matches'}
    else { $arguments += @('--context', ${Context}, '--pretty') }

    $arguments += ${Pattern}
    $arguments += ${Path}

    $arguments += $args

    & rg $arguments $args | out-host -paging
}

function fcs
{
    param(
    [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
    [string]${Pattern},
    [string[]]${Path} = @($PWD.Path),
    [int]${Context} = 0,
    [switch]${CaseSensitive} = $false,
    [switch]${json} = $false,
    [switch]${ListMatchesOnly} = $false,
    [switch]${MultiLine} = $false,
    [switch]${WordsOnly} = $false,
    [switch]${Count} = $false
    )
    $arguments=@()

    $arguments += @('--type', 'cs')
    
    if (-not ${CaseSensitive}) { $arguments += '--ignore-case'}
    if (${json}) { $arguments += '--json'}
    if (${WordsOnly}) { $arguments += '--word-regexp'}
    if (${MultiLine}) { $arguments += '--multiline'}
    if (${Count}) { $arguments += '--count'}
    if (${ListMatchesOnly}) { $arguments += '--files-with-matches'}
    else { $arguments += @('--context', ${Context}, '--pretty') }

    $arguments += ${Pattern}
    $arguments += ${Path}

    $arguments += $args

    & rg $arguments $args | out-host -paging
}

function fcpp
{
    param(
    [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
    [string]${Pattern},
    [string[]]${Path} = @($PWD.Path),
    [int]${Context} = 0,
    [switch]${CaseSensitive} = $false,
    [switch]${json} = $false,
    [switch]${ListMatchesOnly} = $false,
    [switch]${MultiLine} = $false,
    [switch]${WordsOnly} = $false,
    [switch]${Count} = $false
    )
    $arguments=@()

    $arguments += @('--type-add', 'cuda:*.cu', '--type-add', 'cudah:*.cuh', '--type', 'c', '--type', 'cpp', '--type', 'cuda', '--type', 'cudah')
    
    if (-not ${CaseSensitive}) { $arguments += '--ignore-case'}
    if (${json}) { $arguments += '--json'}
    if (${WordsOnly}) { $arguments += '--word-regexp'}
    if (${MultiLine}) { $arguments += '--multiline'}
    if (${Count}) { $arguments += '--count'}
    if (${ListMatchesOnly}) { $arguments += '--files-with-matches'}
    else { $arguments += @('--context', ${Context}, '--pretty') }

    $arguments += ${Pattern}
    $arguments += ${Path}

    $arguments += $args

    & rg $arguments $args | out-host -paging
}

function fjava
{
    param(
    [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
    [string]${Pattern},
    [string[]]${Path} = @($PWD.Path),
    [int]${Context} = 0,
    [switch]${CaseSensitive} = $false,
    [switch]${json} = $false,
    [switch]${ListMatchesOnly} = $false,
    [switch]${MultiLine} = $false,
    [switch]${WordsOnly} = $false,
    [switch]${Count} = $false
    )
    $arguments=@()

    $arguments += @('--type', 'java')
    
    if (-not ${CaseSensitive}) { $arguments += '--ignore-case'}
    if (${json}) { $arguments += '--json'}
    if (${WordsOnly}) { $arguments += '--word-regexp'}
    if (${MultiLine}) { $arguments += '--multiline'}
    if (${Count}) { $arguments += '--count'}
    if (${ListMatchesOnly}) { $arguments += '--files-with-matches'}
    else { $arguments += @('--context', ${Context}, '--pretty') }

    $arguments += ${Pattern}
    $arguments += ${Path}

    $arguments += $args

    & rg $arguments $args | out-host -paging
}

function fpy
{
    param(
    [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
    [string]${Pattern},
    [string[]]${Path} = @($PWD.Path),
    [int]${Context} = 0,
    [switch]${CaseSensitive} = $false,
    [switch]${json} = $false,
    [switch]${ListMatchesOnly} = $false,
    [switch]${MultiLine} = $false,
    [switch]${WordsOnly} = $false,
    [switch]${Count} = $false
    )
    $arguments=@()

    $arguments += @('--type', 'py')
    
    if (-not ${CaseSensitive}) { $arguments += '--ignore-case'}
    if (${json}) { $arguments += '--json'}
    if (${WordsOnly}) { $arguments += '--word-regexp'}
    if (${Count}) { $arguments += '--count'}
    if (${MultiLine}) { $arguments += '--multiline'}
    if (${ListMatchesOnly}) { $arguments += '--files-with-matches'}
    else { $arguments += @('--context', ${Context}, '--pretty') }

    $arguments += ${Pattern}
    $arguments += ${Path}

    $arguments += $args

    & rg $arguments $args | out-host -paging
}

function gdiff
{
    param(
        [Parameter(
            Mandatory=$True,
            ValueFromRemainingArguments=$true
        )][string[]]
        $arguments
    )
    echo $arguments
    & "C:\Program Files\Beyond Compare 4\BComp.exe" $arguments
}
