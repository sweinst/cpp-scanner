function Get-History2()
{
    param(
        [parameter(Mandatory=$false, Position=0 )] 
        $Count = 1000000
        )
    Get-Content  (Get-PSReadLineOption).HistorySavePath -Tail $Count
}

Remove-alias -force -name "h"  -ErrorAction Ignore
New-Alias -Name "h" Get-History2

function Get-FileFromUri {  
    param(  
        [parameter(Mandatory=$true, Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)] [string] [Alias('Uri')] 
        $Url,
        [parameter(Mandatory=$false, Position=1)] [string] [Alias('Folder')] 
        $FolderPath
    )
    process {
        try {
            # resolve short URLs
            $req = [System.Net.HttpWebRequest]::Create($Url)
            $req.Method = "HEAD"
            $response = $req.GetResponse()
            $fUri = $response.ResponseUri
            $filename = [System.IO.Path]::GetFileName($fUri.LocalPath);
            $response.Close()
            # download file
            $destination = (Get-Item -Path ".\" -Verbose).FullName
            if ($FolderPath) { $destination = $FolderPath }
            if ($destination.EndsWith('\')) {
                $destination += $filename
            } else {
                $destination += '\' + $filename
            }
            $webclient = New-Object System.Net.webclient
            $webclient.downloadfile($fUri.AbsoluteUri, $destination)
            write-host -ForegroundColor DarkGreen "downloaded '$($fUri.AbsoluteUri)' to '$($destination)'"
        } catch {
            write-host -ForegroundColor DarkRed $_.Exception.Message
        }  
    }  
} 

Set-Alias wget Get-FileFromUri -Option AllScope

Function Touch-File
{
    param(  
        [parameter(Mandatory=$true, Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)] [SupportsWildcards()] [string[]] $files
    )

    foreach ($pattern in $files) {
        $f = (Get-Item $pattern -ErrorAction SilentlyContinue)
        if ($f -eq $null) {
                write-output $null > $pattern
        }
        else {
            foreach ($file in $f) {
                    (Get-Item $file).LastWriteTime = Get-Date
            }
        }
    }
}

Set-Alias touch Touch-File -Option AllScope

Function Get-LockingProcess {

    [cmdletbinding()]
    Param(
        [Parameter(Position=0, Mandatory=$True,
        HelpMessage="What is the path or filename? You can enter a partial name without wildcards")]
        [Alias("name")]
        [ValidateNotNullorEmpty()]
        [string]$Path
    )

    # Define the path to Handle.exe
    # //$Handle = "G:\Sysinternals\handle.exe"
    $Handle = "handle.exe"

    # //[regex]$matchPattern = "(?<Name>\w+\.\w+)\s+pid:\s+(?<PID>\b(\d+)\b)\s+type:\s+(?<Type>\w+)\s+\w+:\s+(?<Path>.*)"
    # //[regex]$matchPattern = "(?<Name>\w+\.\w+)\s+pid:\s+(?<PID>\d+)\s+type:\s+(?<Type>\w+)\s+\w+:\s+(?<Path>.*)"
    # (?m) for multiline matching.
    # It must be . (not \.) for user group.
    [regex]$matchPattern = "(?m)^(?<Name>\w+\.\w+)\s+pid:\s+(?<PID>\d+)\s+type:\s+(?<Type>\w+)\s+(?<User>.+)\s+\w+:\s+(?<Path>.*)$"

    # skip processing banner
    $data = &$handle -u $path -nobanner
    # join output for multi-line matching
    $data = $data -join "`n"
    $MyMatches = $matchPattern.Matches( $data )

    # //if ($MyMatches.value) {
    if ($MyMatches.count) {

        $MyMatches | foreach {
            [pscustomobject]@{
                FullName = $_.groups["Name"].value
                Name = $_.groups["Name"].value.split(".")[0]
                ID = $_.groups["PID"].value
                Type = $_.groups["Type"].value
                User = $_.groups["User"].value.trim()
                Path = $_.groups["Path"].value
                toString = "pid: $($_.groups["PID"].value), user: $($_.groups["User"].value), image: $($_.groups["Name"].value)"
            } #hashtable
        } #foreach
    } #if data
    else {
        Write-Warning "No matching handles found"
    }
} #end function

# code used for the prompt
# all the remaining code is stolen from the module "oh-my-posh" (https://github.com/JanDeDobbeleer/oh-my-posh)

# to look up unicode symbols: https://unicode-table.com/en/search/?q=E606

$symbols = New-Object -TypeName PSObject -Property @{
    StartSymbol                    = ' '
    TruncatedFolderSymbol          = '..'
    PromptIndicator                = [char]::ConvertFromUtf32(0x25B6) # ▶
    FailedCommandSymbol            = [char]::ConvertFromUtf32(0x2A2F) # ⨯
    ElevatedSymbol                 = [char]::ConvertFromUtf32(0x26A1) # ⚡
    SegmentForwardSymbol           = [char]::ConvertFromUtf32(0xE0B0) # 
    SegmentBackwardSymbol          = [char]::ConvertFromUtf32(0x26A1) # ⚡
    SegmentSeparatorForwardSymbol  = [char]::ConvertFromUtf32(0x26A1) # ⚡
    SegmentSeparatorBackwardSymbol = [char]::ConvertFromUtf32(0x26A1) # ⚡
    PathSeparator                  = [System.IO.Path]::DirectorySeparatorChar
    VirtualEnvSymbol               = [char]::ConvertFromUtf32(0xE606) # 
    HomeSymbol                     = '~'
    RootSymbol                     = '#'
    UNCSymbol                      = '§'
}

function Format-FileSize([int64] $size) {
    if ($size -lt 1Kb)
    {
        return $size
    }
    if ($size -lt 1Mb)
    {
        return "{0:0.0} Kb" -f ($size/1Kb)
    }
    if ($size -lt 1Gb)
    {
        return "{0:0.0} Mb" -f ($size/1Mb)
    }
    if ($size -lt 1Tb)
    {
        return "{0:0.0} Gb" -f ($size/1Gb)
    }
    return "{0:0.0} Tb" -f ($size/1Tb)
}

if ($IsWindows)
{
    function df {
        Get-PSDrive -PSProvider 'FileSystem' | 
        Format-Table @{
                        Name = 'Drive'
                        Expression = { $_.Name }
                    },
                    @{
                        Name = 'Used'
                        Expression = { Format-FileSize($_.used) }
                        FormatString = 'N3'
                        Align='right'
                    },
                    @{
                        Name = 'Free'
                        Expression = { Format-FileSize($_.free) }
                        FormatString = 'N3'
                        Align='right'
                    }
    }
}


function du {
        param(
        [string]
        $Path=".",
        [switch]
        $SortBySize,
        [switch]
        $Summary
    )
    $path = (get-item ".").FullName
    $groupedList = Get-ChildItem -Recurse -File $Path | 
        Group-Object directoryName | 
            select name,@{name='length'; expression={($_.group | Measure-Object -sum length).sum } }
    $results = ($groupedList | % {
        $dn = $_
        if ($summary -and ($path -ne $dn.name)) {
            return
        }
        $size = ($groupedList | where { $_.name -like "$($dn.name)*" } | Measure-Object -Sum length).sum
        New-Object psobject -Property @{ 
            Directory=$dn.name; 
            Size=Format-FileSize($size);
            Bytes=$size` 
        }
    })
    if ($SortBySize)
        { $results = $results | sort-object -property Bytes }
    $results | more
}

function split-path-recursive([string]$Path)
{
    $path = (Get-Item $path).FullName
    $res = @()
    while ($path -ne "") {
        $res += (Split-Path -leaf $path)
        $path = (Split-Path -parent $path)
    }
    return $res
}

$__reg_hives = @{
    "HKEY_CLASS_ROOT"= "HKCR";
    "HKEY_CURRENT_USER"= "HKCU";
    "HKEY_LOCL_MACHINE"= "HKLM";
    "HKEY_USERS"= "HKU";
    "HKEY_CURRENT_CONFIG"= "HKCC"
}

function abbreviate-path([string]$Path, [int]$max_components=5)
{
    $d = (Get-Item $path)
    $pspr = $d.PSProvider.ToString()
    $path = $d.PSPath.SubString($pspr.Length+2)

    if ([string]::IsNullOrEmpty($path))
    {
        # alias, variable env, function, ...
        return $d.PSProvider.Name + ":>"
    }
    # use '~' for home
    if ($d.PSProvider.Name -eq 'FileSystem') {
        $h = $HOME.TrimEnd('/', '\')
        if ($path.StartsWith($h)) {
            $path = '~' + $path.SubString($h.Length)
        }
    }
    # split the path into components
    $o_path = $path.Clone()
    [string[]]$dirs = @()
    while ($path -ne "") {
        if ($path -eq '~') {
            $dirs += "~"
        }
        else {
            $dirs += (Split-Path -leaf $path)
        }
        $path = (Split-Path -parent $path)
    }
    # abbreviate registry hive names
    if ($d.PSProvider.Name -eq 'Registry') {
        $hn = $__reg_hives[$dirs[0]]
        if ($hn -ne $null) {
            $dirs[0] = $hn
        }
    }
    [system.array]::reverse($dirs)
    if ($dirs.Count -le $max_components) {
        return [IO.Path]::Combine($dirs)
    }
    # NB: $dirs[0..4] returns 4 elements 
    $s = [int]($max_components / 2) - 1
    # NB: $dirs[7..Count] returns Count-7 elements 
    $e = $dirs.Count
    $es = $dirs.Count - [int]($max_components / 2 + 0.5)
    [string[]] $split = $dirs[0..$s] + @('...') + $dirs[$es..$e]
    return [IO.Path]::Combine($split)
}


# $src = Get-Content -Path (Join-Path $PSScriptRoot "Wallpaper.cs") | Out-String
# Add-Type -TypeDefinition $src


