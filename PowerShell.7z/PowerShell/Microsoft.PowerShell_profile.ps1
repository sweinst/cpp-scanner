if (-Not (Test-Path variable:IsWindows)) { $IsWindows = $True }
$isWSL = ((-not $IsWindows) -and (sls -Path /proc/version -Pattern microsoft -Quiet))

$poshDir = (Split-Path $PROFILE -Parent)
$ScriptsPath = (Join-Path ${poshDir} "Scripts")
$tmpModule = $(Join-Path $poshDir Modules)

if ($env:PSModulePath){
    $env:PSModulePath = "$tmpModule$([IO.Path]::PathSeparator)$env:PSModulePath"
}
else {
    $env:PSModulePath = "$tmpModule"
}
$env:Path += "$([System.IO.Path])${ScriptsPath}"

#Import-Module PSColor
Import-Module SergeUtils
# Import-Module Get-ChildItemColor
Import-Module posh-git
Import-Module PSColor
Import-Module Microsoft.Powershell.Management
Import-Module "$($(Get-Item $(Get-Command scoop.ps1).Path).Directory.Parent.FullName)\modules\scoop-completion"


. (Join-Path ${poshDir} 'psreadline-settings.ps1')
. (Join-Path ${poshDir} 'progutils.ps1')
. (Join-Path ${poshDir} 'ripgrep.ps1')
. (Join-Path ${poshDir} 'utils.ps1')

. (Join-Path ${poshDir} 'aws.ps1')

if ($IsWindows) 
{
    # Chocolatey profile
    #$ChocolateyProfile = "$env:ChocolateyInstall\helpers\chocolateyProfile.psm1"
    #if (Test-Path($ChocolateyProfile)) {
    #  Import-Module "$ChocolateyProfile"
    #}
}

# By default, sls selects all matches
$PSDefaultParameterValues['Select-String:AllMatches'] = $true         

if ($IsWindows) 
{
    $env:Path += ";" + $ScriptsPath ####+ ';D:\Apps' 
    $hostname = $env:COMPUTERNAME
    $user = $env:USERNAME
    . (Join-Path (Split-Path $PROFILE -Parent) 'vstudio.ps1')
    Import-Module PowerColorLS
    Set-Alias -Name ls -Value PowerColorLS -Option AllScope
}
else 
{
    $hostname = $(hostname -s)
    $user = $env:LOGNAME
}

# allow to deal with the proxy
$browser = New-Object System.Net.WebClient
$browser.Proxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials

function Get-PowerShellVersion
{
    # accessing the value indirectly so it can be mocked
    (Get-Variable 'PSVersionTable' -ValueOnly).PsVersion.Major
}


$IsANSITerminal=$Host.UI.SupportsVirtualTerminal

function e()
{
    param(
        [parameter(Position=0)]
        [string[]] $Files,
        [switch] $NewWindow
        )
    $arguments = @()
    if ($NewWindow) {
        $arguments += "-n"
    }
    else {
        $arguments += "-a"
    }
    $Files = ($Files | % {
        if (Test-Path -PathType Container $_) {
            Get-Item $_
        }
        else {
            Get-ChildItem $_
        }
    } | Select-Object -Expand FullName)
    if ($IsWindows) 
    {
        $arguments += $Files
        & "C:\Program Files\Sublime Text 3\sublime_text.exe" $arguments    
    }
    else
    {
        if ($isWSL) 
        {
            $Files | % { $arguments += (wslpath -wa $_) }
            & (wslpath -ua "C:\Program Files\Sublime Text 3\sublime_text.exe") $arguments
        }
        else 
        {
            $arguments += $Files
            & "subl" $arguments
        }
    }
}

function e2()
{
     [CmdletBinding()]
     Param (
        [Parameter(ValueFromPipeline)]
        [string] $File,
        [switch] $NewWindow
    )

    begin {
        $arguments = @()
        $Files = @()
        if ($NewWindow) {
            $arguments += "-n"
        }
        else {
            $arguments += "-a"
        }
    }

    process {
        $Files += $File
    }

    end {
        if ($IsWindows) 
        {
            $arguments += $Files
            & "C:\Program Files\Sublime Text 3\sublime_text.exe" $arguments    
        }
        else
        {
            if ($isWSL) 
            {
                $Files | % { $arguments += (wslpath -wa $_) }
                & (wslpath -ua "C:\Program Files\Sublime Text 3\sublime_text.exe") $arguments
            }
            else 
            {
                $arguments += $Files
                & "subl" $arguments
            }
        }
    }
}

if ($IsWindows)
{
    Set-Alias vi "vim"
    $IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')

#region conda initialize
# !! Contents within this block are managed by 'conda init' !!
    (& "${home}\Anaconda3\Scripts\conda.exe" "shell.powershell" "hook") | Out-String | Invoke-Expression
#endregion
    
    function Prompt
    {
        Write-Host
        if ($IsAdmin) 
        {
            Write-Host -NoNewline -Object "$($symbols.ElevatedSymbol) " -ForegroundColor Yellow -BackgroundColor Black
        }
        Write-Host -NoNewline "$user@$hostname" -ForegroundColor Red
        Write-Host -NoNewline "$($symbols.SegmentForwardSymbol)" -ForegroundColor Black -BackgroundColor Green

        Write-Host -NoNewline $env:CONDA_PROMPT_MODIFIER -ForegroundColor Black -BackgroundColor Green
        Write-Host -NoNewline "$($symbols.SegmentForwardSymbol)" -ForegroundColor Green -BackgroundColor Blue

        Write-Host -NoNewline (get-date).Tostring("yyyy-MM-dd HH:mm:ss") -ForegroundColor White -BackgroundColor Blue
        Write-Host -NoNewline "$($symbols.SegmentForwardSymbol)" -ForegroundColor Blue -BackgroundColor Yellow

        Write-Host -NoNewline (Abbreviate-Path $pwd 5) -ForegroundColor Black  -BackgroundColor Yellow
        Write-Host -NoNewline "$($symbols.SegmentForwardSymbol)" -ForegroundColor Yellow -BackgroundColor Black

        $host.UI.RawUI.WindowTitle = $pwd.ProviderPath

        return " "
    }
}
else 
{
    Set-Alias vi "vim"
    $IsAdmin=((whoami) -eq 'root')
    $IsANSITerminal=$Host.UI.SupportsVirtualTerminal
    
    $esc=[char]0x1b
    $RESET_ALL="$esc[0m"
    $BOLD="$esc[1m"
    $UNDERLINE="$esc[2m"
    $ITALIC="$esc[3m"
    $WHITE="$esc[37"
    $YELLOW="$esc[33m"
    $GRAY="$esc[30m"
    $CYAN="$esc[36m"
    $BLUE="$esc[34m"
    $RED="$esc[31m"
    $PURPLE="$esc[35m"

    function Prompt
    {
        # NB: I haven't found a way for setting colors on the last line
        return "$BOLD$YELLOW[$((get-date).Tostring('yyyy-MM-dd HH:mm:ss'))] $ITALIC$BLUE{$($executionContext.SessionState.Path.CurrentLocation)}$RESET_ALL`n" +
            "$env:LOGNAME@$hostname> "
    }

    function ls
    {
        /bin/ls -F ---color $args
    }

    function ll
    {
        ls -lh $args
    }
}

# redefine cd
Remove-Alias cd
Set-Alias cd cdim -Option AllScope
# PsReadline keeps a cache of the cd alias, we need to reset it
# see https://jamesone111.wordpress.com/2019/11/24/redefining-cd-in-powershell/
if (Get-Module PSReadLine) {
    Remove-Module -Force PsReadline
    Import-Module -Force PSReadLine
}


