<#
.SYNOPSIS
  Delete files in a folder not present in another folder
.PARAMETER Source
  The folder to compare to
.PARAMETER Target
  The folder where to delete the extra files
#>

param(  
  [ValidateNotNullOrEmpty()]
  [string] $Source,

  [ValidateNotNullOrEmpty()]
  [string] $Target
)

$Source = (Resolve-Path $Source).Path
$Target = (Resolve-Path $Target).Path

Get-ChildItem -file -recurse $Target | % {
    $Source_File = (Join-Path $Source ([System.IO.Path]::GetRelativePath($Target, $_.FullName)))
    if (-Not (Test-Path $Source_File)) {
        Write-Host "Deleting $($_.FullName)"
        Remove-Item $_
    }
}


