<#
.SYNOPSIS
  Set the desktop background
.PARAMETER Color
  Set the desktop backgound to this color
.PARAMETER Picture
  Set the desktop backgound to a Picture at the specified path.
.PARAMETER Slideshow
  Set the desktop backgound to a Slideshow with the images of the sepcified folder
#>

# NB: befor eusing it, you need to add
# Add-type -AssemblyName System.Drawing

param(  
  [Sytem.Drawing.Color] $Color,
  [ValidateNotNullOrEmpty()]
  [string] $Target
)
