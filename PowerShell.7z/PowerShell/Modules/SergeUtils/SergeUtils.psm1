Import-Module "$PSScriptRoot\cdim.psm1" -Force


